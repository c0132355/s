(function () {
  var svg = document.getElementById("picture");
  var notes = Array.prototype.slice.call(document.querySelectorAll(".note"));
  var sections = { map: "sec-map", people: "sec-people", minerals: "sec-minerals", disease: "sec-disease", migration: "sec-migration" };
  var reduce = window.matchMedia("(prefers-reduced-motion: reduce)").matches;

  if (reduce && svg && svg.pauseAnimations) svg.pauseAnimations();

  function focusOn(target) {
    if (target) svg.setAttribute("data-focus", target);
    else svg.removeAttribute("data-focus");
  }

  function setActive(note) {
    notes.forEach(function (n) { n.classList.toggle("is-on", n === note); });
  }

  notes.forEach(function (note) {
    var target = note.dataset.target;

    note.addEventListener("mouseenter", function () { focusOn(target); });
    note.addEventListener("mouseleave", function () {
      var active = document.querySelector(".note.is-on");
      focusOn(active ? active.dataset.target : null);
    });
    note.addEventListener("focus", function () { focusOn(target); });

    function choose() {
      var already = note.classList.contains("is-on");
      setActive(already ? null : note);
      focusOn(already ? null : target);
      if (!already) {
        var el = document.getElementById(sections[target]);
        if (el) el.scrollIntoView({ behavior: reduce ? "auto" : "smooth", block: "center" });
      }
    }

    note.addEventListener("click", choose);
    note.addEventListener("keydown", function (e) {
      if (e.key === "Enter" || e.key === " ") { e.preventDefault(); choose(); }
    });
  });

  // клик по куску рисунка выбирает подходящую заметку
  Object.keys(sections).forEach(function (key) {
    var el = document.getElementById(sections[key]);
    if (!el) return;
    el.style.cursor = "pointer";
    el.addEventListener("click", function () {
      var note = notes.filter(function (n) { return n.dataset.target === key; })[0];
      if (!note) return;
      setActive(note);
      focusOn(key);
      note.scrollIntoView({ behavior: reduce ? "auto" : "smooth", block: "center" });
    });
  });

  // полоски наций заполняются, когда заметка появляется на экране
  var bars = document.querySelectorAll(".note");
  if ("IntersectionObserver" in window) {
    var io = new IntersectionObserver(function (entries) {
      entries.forEach(function (en) {
        if (en.isIntersecting) { en.target.classList.add("bars-on"); io.unobserve(en.target); }
      });
    }, { threshold: 0.4 });
    bars.forEach(function (b) { io.observe(b); });
  } else {
    bars.forEach(function (b) { b.classList.add("bars-on"); });
  }
})();
