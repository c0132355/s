# Рисуем Кыргызстан

Сайт на Flask с детским рисунком Кыргызстана и небольшими анимациями.

## Запуск

    pip install -r requirements.txt
    python app.py

Открой http://127.0.0.1:5000

## Структура

    app.py                        Flask: страница и /api/facts
    templates/index.html          страница
    templates/picture.svg.html    рисунок (встроенный SVG)
    static/style.css              стили и анимации
    static/app.js                 подсветка частей рисунка
